package Main;

import java.util.Scanner;
import org.springframework.security.crypto.bcrypt.*;

public class Encryptor {

    public Encryptor() {
    }

    public String encrypt(String plainText) {
        String hash = BCrypt.hashpw(plainText, BCrypt.gensalt(12));
        return hash;
    }
    
    public boolean checkPassword(String p1, String hash){
        return BCrypt.checkpw(p1, hash);
    }
    
}

class tester {
    
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        Encryptor e = new Encryptor();
        String pass = "password";
        String hash = e.encrypt(pass);
        System.out.println("The password: " + pass);
        System.out.println("The Hash: " + hash);
        System.out.print("Verification - Enter password again: ");
        String input = scan.next();
        System.out.println("Input Hash: " + e.encrypt(input));
        System.out.println("Passowrds Match: " + e.checkPassword(input, hash));
    }
}


/*

final private String EncryptionKey = "357638792F413F4428472B4B62506553";
public String encrypt(String plainText) throws Exception {
        Key aesKey = new SecretKeySpec(EncryptionKey.getBytes(), "AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, aesKey);
        byte[] encrypted = cipher.doFinal(plainText.getBytes());
        return Base64.getEncoder().encodeToString(encrypted);
    }

    public String decrypt(String encryptedText) throws Exception {
        Key aesKey = new SecretKeySpec(EncryptionKey.getBytes(), "AES");
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, aesKey);
        byte[] decrypted = cipher.doFinal(Base64.getDecoder().decode(encryptedText));
        return new String(decrypted);
    }

    public String getEncryptionKey() {
        return EncryptionKey;
    }
*/
